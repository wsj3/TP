'use client' 
 
export default function SettingsLayout({ children }) { 
  return ( 
    <div className="w-full"> 
      {children} 
    </div> 
  ) 
} 
